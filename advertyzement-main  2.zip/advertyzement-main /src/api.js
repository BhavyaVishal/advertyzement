const BASE_URL = 'https://world.openfoodfacts.org';

export const fetchProducts = async ({ searchTerm, selectedCategory, sortCriteria, sortOrder, page }) => {
  let url = `${BASE_URL}/cgi/search.pl?action=process&json=true&page=${page}&page_size=20`;
  
  if (searchTerm) {
    url += `&search_terms=${searchTerm}`;
  }
  if (selectedCategory) {
    url += `&tagtype_0=categories&tag_contains_0=contains&tag_0=${selectedCategory}`;
  }
  if (sortCriteria) {
    url += `&sort_by=${sortCriteria}&sort_order=${sortOrder}`;
  }
  
  const response = await fetch(url);
  const data = await response.json();
  return data.products;
};

export const fetchCategories = async () => {
  const response = await fetch(`${BASE_URL}/categories.json`);
  const data = await response.json();
  return Object.keys(data.tags).slice(0, 20); // Limit to top 20 categories
};

export const fetchProductDetails = async (productId) => {
  const response = await fetch(`${BASE_URL}/api/v0/product/${productId}.json`);
  const data = await response.json();
  return data.product;
};

export const searchByBarcode = async (barcode) => {
  const response = await fetch(`${BASE_URL}/api/v0/product/${barcode}.json`);
  const data = await response.json();
  return data.status === 1 ? data.product : null;
};