import React, { useState, useEffect, useCallback } from 'react';
import { useInView } from 'react-intersection-observer';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import ProductCard from './ProductCard';
import CategoryFilter from './CategoryFilter';
import SortControl from './SortControl';
import { fetchProducts, fetchCategories } from '../api';

const HomePage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [sortCriteria, setSortCriteria] = useState('product_name');
  const [sortOrder, setSortOrder] = useState('asc');
  const [searchTerm, setSearchTerm] = useState('');
  const [barcodeSearch, setBarcodeSearch] = useState('');
  const [page, setPage] = useState(1);

  const { ref, inView } = useInView({
    threshold: 0,
  });

  useEffect(() => {
    fetchCategories().then(setCategories);
  }, []);

  useEffect(() => {
    if (inView) {
      loadMoreProducts();
    }
  }, [inView]);

  const searchProducts = async (reset = false) => {
    if (reset) {
      setProducts([]);
      setPage(1);
    }
    setLoading(true);
    try {
      const newProducts = await fetchProducts({
        searchTerm,
        selectedCategory,
        sortCriteria,
        sortOrder,
        page: reset ? 1 : page,
      });
      setProducts(prev => reset ? newProducts : [...prev, ...newProducts]);
      setPage(prev => reset ? 2 : prev + 1);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
    setLoading(false);
  };

  const loadMoreProducts = useCallback(() => {
    if (!loading) {
      searchProducts();
    }
  }, [loading, searchProducts]);

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Food Product Search</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <Input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search products by name"
        />
        <Input
          type="text"
          value={barcodeSearch}
          onChange={(e) => setBarcodeSearch(e.target.value)}
          placeholder="Search by barcode"
        />
      </div>
      <div className="flex mb-4">
        <Button onClick={() => searchProducts(true)} className="mr-2">Search</Button>
        <Button onClick={() => {}}>Search by Barcode</Button>
      </div>
      <div className="flex mb-4">
        <CategoryFilter
          categories={categories}
          selectedCategory={selectedCategory}
          onCategoryChange={(value) => { setSelectedCategory(value); searchProducts(true); }}
        />
        <SortControl
          sortCriteria={sortCriteria}
          sortOrder={sortOrder}
          onSortChange={(criteria, order) => {
            setSortCriteria(criteria);
            setSortOrder(order);
            searchProducts(true);
          }}
        />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
      {loading && <p className="text-center mt-4">Loading...</p>}
      <div ref={ref} style={{ height: '10px' }}></div>
    </div>
  );
};

export default HomePage;