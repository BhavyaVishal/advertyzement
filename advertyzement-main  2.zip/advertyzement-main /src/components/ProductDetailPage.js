import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAppContext } from '../AppContext';
import { fetchProductDetails } from '../api';

const ProductDetailPage = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const { dispatch } = useAppContext();

  useEffect(() => {
    fetchProductDetails(id).then(setProduct).finally(() => setLoading(false));
  }, [id]);

  const addToCart = () => {
    dispatch({ type: 'ADD_TO_CART', payload: product });
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  if (!product) {
    return <p>Product not found</p>;
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">{product.product_name}</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <img src={product.image_url} alt={product.product_name} className="w-full h-auto object-cover" />
        <div>
          <h2 className="text-xl font-semibold mb-2">Ingredients</h2>
          <p>{product.ingredients_text}</p>
          <h2 className="text-xl font-semibold mt-4 mb-2">Nutritional Values (per 100g)</h2>
          <ul>
            <li>Energy: {product.nutriments.energy_100g} kcal</li>
            <li>Fat: {product.nutriments.fat_100g}g</li>
            <li>Carbs: {product.nutriments.carbohydrates_100g}g</li>
            <li>Proteins: {product.nutriments.proteins_100g}g</li>
          </ul>
          <h2 className="text-xl font-semibold mt-4 mb-2">Labels</h2>
          <p>{product.labels || 'No labels available'}</p>
          <Button onClick={addToCart} className="mt-4">Add to Cart</Button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;