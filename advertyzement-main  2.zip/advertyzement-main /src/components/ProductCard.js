import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAppContext } from '../AppContext';

const ProductCard = ({ product }) => {
  const { dispatch } = useAppContext();

  const addToCart = () => {
    dispatch({ type: 'ADD_TO_CART', payload: product });
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <CardTitle>{product.product_name}</CardTitle>
      </CardHeader>
      <CardContent>
        <img src={product.image_url} alt={product.product_name} className="w-full h-48 object-cover mb-2" />
        <p><strong>Category:</strong> {product.categories}</p>
        <p><strong>Ingredients:</strong> {product.ingredients_text}</p>
        <p><strong>Nutrition Grade:</strong> {product.nutrition_grade_fr?.toUpperCase()}</p>
        <div className="flex justify-between mt-2">
          <Link to={`/product/${product.id}`}>
            <Button>View Details</Button>
          </Link>
          <Button onClick={addToCart}>Add to Cart</Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCard;