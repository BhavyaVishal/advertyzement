import React from 'react';
import { useAppContext } from '../AppContext';
import { Button } from '@/components/ui/button';

const Cart = () => {
  const { state, dispatch } = useAppContext();

  const removeFromCart = (product) => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: product });
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Shopping Cart</h1>
      {state.cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <ul>
          {state.cart.map((item) => (
            <li key={item.id} className="flex justify-between items-center mb-2">
              <span>{item.product_name}</span>
              <Button onClick={() => removeFromCart(item)}>Remove</Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Cart;