import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { AppProvider } from './AppContext';
import HomePage from './components/HomePage';
import ProductDetailPage from './components/ProductDetailPage';
import Cart from './components/Cart';

const App = () => {
  return (
    <AppProvider>
      <Router>
        <div className="min-h-screen bg-gray-100">
          <Navbar />
          <Switch>
            <Route exact path="/" component={HomePage} />
            <Route path="/product/:id" component={ProductDetailPage} />
            <Route path="/cart" component={Cart} />
          </Switch>
        </div>
      </Router>
    </AppProvider>
  );
};

export default App;

